


<?php


// varibles i identfy to connect

$host = "sql308.epizy.com" ;
$user = "epiz_32364193";
$pass= "xrrTwbnSc6ZN" ;
$db = "epiz_32364193_riyadh_trail" ;
// connect function 
$con = mysqli_connect($host,$user,$pass,$db) ;
// CHECK CONNECTION STATUS
if($con)
{
    //echo "connected" ;
}

// get data from database
$res = mysqli_query($con , "select * from place WHERE type='attraction' ");
$s1 = mysqli_fetch_array($res); //albjiry

$s2 = mysqli_fetch_array($res); // alghader ;
$s3 = mysqli_fetch_array($res); // bulervard ;
$s4 = mysqli_fetch_array($res); //edge of the world ;
$s5 = mysqli_fetch_array($res); // historical diryah ;
$s6 = mysqli_fetch_array($res); // king abdulla park ;
$s7 = mysqli_fetch_array($res);  // king_saud_uni_stadi ;
$s8 = mysqli_fetch_array($res); // kingdom tower ;
$s9 = mysqli_fetch_array($res);  // masmak palace ;
$s10 = mysqli_fetch_array($res); // national musem ;
//$s2 = mysqli_fetch_array($res) ; //jolt
echo $s1[0]." ".$s1[3];
echo "fofo dubai" ;

?>






<html>
    <head>
        <title>

        </title>
        <style>
            form{
               
                background-image: url(so.jpg);
                background-size: cover;
                float:left;
                margin:40px ;
                width: 300px;
                height: 187px;
                float: left;
                margin-left: 20px;
                
                
                
            }

           
            .TransperntBorder
            {
                background: rgba(255,255,255,0.5);
            }
           
            
           .headder
           {
            background-image: url(sec_header/atractions_3.webp);
            background-size: cover;
            font-size:xx-large;
            font-weight: bold;
            width: 1480px;
            height: 500px;
            border-color: black;
           }
           body
           {
            background-color :whitesmoke;
           }
           .ResTittle{
            font-size:xx-large;
            font-weight: bold;
            background-color: rgba(255,255,255,0.5);

           }

           /* the rest is for class to  each coffe pic*/
           .albjiry
           {
            background-image: url(<?php echo $s1[3]  ?>);
                background-size: cover;
           }

           .alghader_walking_area
           {
            background-image: url(<?php echo $s2[3]  ?>);
                background-size: cover;
           }
           .bulevard
           {
            background-image: url(<?php echo $s3[3]  ?>);
                background-size: cover;
           }

           .edge
           {
            background-image: url(<?php echo $s4[3]  ?>);
                background-size: cover;
           }
           
           .historical_diryah
           {
            background-image: url(<?php echo $s5[3]  ?>);
                background-size: cover;
           }

           .king_abdula_park
           {
            background-image: url(<?php echo $s6[3]  ?>);
                background-size: cover;
           }

           .king_saud_st
           {
            background-image: url(<?php echo $s7[3]  ?>);
                background-size: cover;
           }

           .king_dom_tower
           {
            background-image: url(<?php echo $s8[3]  ?>);
                background-size: cover;
           }

           .masmak
           {
            background-image: url(<?php echo $s9[3]  ?>);
                background-size: cover;
           }

           .National_musem
           {
            background-image: url(<?php echo $s10[3]  ?>);
                background-size: cover;
           }
            
            

        </style>

    </head>

    <body>
        
       <div class="headder" align="center">riyadh cafes</div>
       
       
        <form class="albjiry">
            <div class="ResTittle" > &nbsp; Albujairy</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form  class="alghader_walking_area">
            <div class="ResTittle" > &nbsp; ghader walking area</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form class="bulevard">
            <div class="ResTittle" > &nbsp; Bulevard riyadh city</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form class="edge">
            <div class="ResTittle" > &nbsp; edge of the world</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form class="National_musem">
            <div class="ResTittle" > &nbsp; National musem</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form class="king_saud_st">
            <div class="ResTittle" > &nbsp; king saud stadum</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form class="historical_diryah">
            <div class="ResTittle" > &nbsp; Historical diryah</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form class="king_abdula_park">
            <div class="ResTittle" > &nbsp; king abdila park</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="king_saud_st"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form class="king_dom_tower">
            <div class="ResTittle" > &nbsp; Kingdom tower</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form class="masmak">
            <div class="ResTittle" > &nbsp; Masmal palace</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         

         
     
    

    </body>
</html>