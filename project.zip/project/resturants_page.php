<?php


// varibles i identfy to connect

$host = "sql308.epizy.com" ;
$user = "epiz_32364193";
$pass= "xrrTwbnSc6ZN" ;
$db = "epiz_32364193_riyadh_trail" ;
// connect function 
$con = mysqli_connect($host,$user,$pass,$db) ;
// CHECK CONNECTION STATUS
if($con)
{
    //echo "connected" ;
}

// get data from database
$res = mysqli_query($con , "select * from place WHERE type='restaurant' ");
$s1 = mysqli_fetch_array($res); //avak

$s2 = mysqli_fetch_array($res); // beef bar ;
$s3 = mysqli_fetch_array($res); // fares_breakfast ;
$s4 = mysqli_fetch_array($res); //miazu ;
$s5 = mysqli_fetch_array($res); // monky house ;
$s6 = mysqli_fetch_array($res); // najdi village ;
$s7 = mysqli_fetch_array($res);  // roka ;
$s8 = mysqli_fetch_array($res); // san carlo ;
$s9 = mysqli_fetch_array($res);  // shababyk resturant ;
$s10 = mysqli_fetch_array($res); // wagu ;
//$s2 = mysqli_fetch_array($res) ; //jolt
echo $s1[0]." ".$s1[3];


?>





<html>
    <head>
        <title>

        </title>
        <style>
            form{
               
                background-image: url(so.jpg);
                background-size: cover;
                float:left;
                margin:40px ;
                width: 300px;
                height: 187px;
                float: left;
                margin-left: 20px;
                
                
                
            }

           
            .TransperntBorder
            {
                background: rgba(255,255,255,0.5);
            }
           
            
           .headder
           {
            background-image: url(sec_header/ress_header.png);
            background-size: cover;
            font-size:xx-large;
            font-weight: bold;
            width: 1480px;
            height: 500px;
            border-color: black;
           }
           body
           {
            background-color :whitesmoke;
           }
           .ResTittle{
            font-size:xx-large;
            font-weight: bold;
            background-color: rgba(255,255,255,0.5);

           }

           /* the rest is for class to  each coffe pic*/
           .miazu
           {
            background-image: url(<?php echo $s4[3]  ?>);
                background-size: cover;
           }

           .monkey_house
           {
            background-image: url(<?php echo $s5[3]  ?>);
                background-size: cover;
           }
           .avak
           {
            background-image: url(<?php echo $s1[3]  ?>);
                background-size: cover;
           }

           .beef_bar
           {
            background-image: url(<?php echo $s2[3]  ?>);
                background-size: cover;
           }
           
           .san_carlo
           {
            background-image: url(<?php echo $s8[3]  ?>);
                background-size: cover;
           }

           .fares_breakfast
           {
            background-image: url(<?php echo $s3[3]  ?>);
                background-size: cover;
           }

           .najd_village
           {
            background-image: url(<?php echo $s6[3]  ?>);
                background-size: cover;
           }

           .wagiu_burger
           {
            background-image: url(<?php echo $s10[3]  ?>);
                background-size: cover;
           }

           .shababyk
           {
            background-image: url(<?php echo $s9[3]  ?>);
                background-size: cover;
           }

           .ROKA
           {
            background-image: url(<?php echo $s7[3]  ?>);
                background-size: cover;
           }
            
            

        </style>

    </head>

    <body>
        
       <div class="headder" align="center">riyadh cafes</div>
       
       
        <form class="ROKA">
            <div class="ResTittle" > &nbsp; Roka</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form  class="miazu">
            <div class="ResTittle" > &nbsp; Miazu</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form class="san_carlo">
            <div class="ResTittle" > &nbsp; San carlo</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form class="beef_bar">
            <div class="ResTittle" > &nbsp; Beef bar</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form class="monkey_house">
            <div class="ResTittle" > &nbsp; MINKY House</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form class="fares_breakfast">
            <div class="ResTittle" > &nbsp; fares Breakfast</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form class="najd_village">
            <div class="ResTittle" > &nbsp; Najdi village</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form class="avak">
            <div class="ResTittle" > &nbsp; Avak</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form class="wagiu_burger">
            <div class="ResTittle" > &nbsp; wagiu burger</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         <form class="shababyk">
            <div class="ResTittle" > &nbsp; Shababik</div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
            
            
            <div class="TransperntBorder"> &nbsp; <img src="icons/like.png" width="20px"> </div>
        
    
    
         </form>

         

         
     
    

    </body>
</html>